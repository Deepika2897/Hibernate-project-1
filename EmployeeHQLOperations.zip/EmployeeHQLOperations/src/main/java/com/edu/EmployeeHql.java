package com.edu;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hqlemployee")
public class EmployeeHql 
{
	@Id
	private int eid;
	private String ename;
	private float esalary;
	private String eaddress;
	private int edeptno;
	public EmployeeHql(int eid, String ename, float esalary, String eaddress, int edeptno) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esalary = esalary;
		this.eaddress = eaddress;
		this.edeptno = edeptno;}
	public EmployeeHql() {
		super();
	}
public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public float getEsalary() {
		return esalary;
	}
	public void setEsalary(float esalary) {
		this.esalary = esalary;
	}
	public String getEaddress() {
		return eaddress;
	}
	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}
	public int getEdeptno() {
		return edeptno;
	}
	public void setEdeptno(int edeptno) {
		this.edeptno = edeptno;
	}


	@Override
	public String toString() {
		return "EmployeeHql [eid=" + eid + ", ename=" + ename + ", esalary=" + esalary + ", eaddress=" + eaddress
				+ ", edeptno=" + edeptno + "]";
	}
	
	
	
	
	
	

}
