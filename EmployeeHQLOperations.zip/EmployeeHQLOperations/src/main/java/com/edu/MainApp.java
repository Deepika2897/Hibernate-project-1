package com.edu;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;



public class MainApp {

	public static void main(String[] args) {
		Configuration con=new Configuration().configure().addAnnotatedClass(EmployeeHql.class);
		ServiceRegistry sreg=new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf=con.buildSessionFactory(sreg);
		Session ss=sf.openSession();
		Transaction tran=ss.beginTransaction();
		
		/*EmployeeHql e1=new EmployeeHql(1, "jana", 40000f, "chennai", 100);
		ss.save(e1);
		EmployeeHql e2=new EmployeeHql(2, "kani", 50000f, "bangalore", 102);
		ss.save(e2);
		EmployeeHql e3=new EmployeeHql(3, "thisha", 44000f, "chennai", 100);
		ss.save(e3);
		EmployeeHql e4=new EmployeeHql(4, "thilak", 60000f, "hydrabed", 104);
		ss.save(e4);
		EmployeeHql e5=new EmployeeHql(5, "divya", 30000f, "pune", 104);
		ss.save(e5);*/
		
		/*EmployeeHql ehql=(EmployeeHql) ss.get(EmployeeHql.class, 1);
		
		System.out.println(ehql);//getting single record with to string method
		
		//getting single record by own format
		System.out.println("empid= "+ehql.getEid() +"empname= "+ehql.getEname() +"empsalary= "+ehql.getEsalary() +"empaddress= "+ehql.getEaddress() +"empdepno= "+ehql.getEdeptno());
		*/
		
		//retrieving all the records
		/*Query q=ss.createQuery("from EmployeeHql");
		List l=q.list();
		Iterator<EmployeeHql> iob=l.iterator();
		while(iob.hasNext())
		{
			EmployeeHql ehql=iob.next();
			System.out.println("empid=" +ehql.getEid() +" empname=" +ehql.getEname() +" empsalary="+ ehql.getEsalary() +" empaddress="+ ehql.getEaddress() +" empdepno="+ ehql.getEdeptno());
			
		}*/
		
		//Query q=ss.createQuery("update EmployeeHql set ename=:n where eid=:i");
		//q.setParameter("n", "keerthi");
		//q.setParameter("i", 2);
		
		/*Query q=ss.createQuery("update EmployeeHql set esalary=:n where eid=:i");
		q.setParameter("n", 60000f);
		q.setParameter("i", 1);
		int i=q.executeUpdate();
		if(i>0)
		{
			System.out.println("record is inserted");
		}
		else
		{
			System.out.println("not inserted");
		}*/
		
		//deleting single record
		/*Query q=ss.createQuery("delete from EmployeeHql where eid=:i");
		q.setParameter("i", 2);
		int i=q.executeUpdate();
		if(i>0)
		{
			System.out.println("record is deleted");
		}
		else
		{
			System.out.println("not deleted");
		}*/
		// total salary
		 Query sumob=ss.createQuery("select sum(esalary) from EmployeeHql");
		 List sl=sumob.list();
		 System.out.println("Total sal="+sl.get(0));
		
		 //minimum salary
		 Query minob=ss.createQuery("select min(esalary) from EmployeeHql");
		 List minl=minob.list();
		 System.out.println("Minimumsal="+minl.get(0));
		 
		 //maximum salary
		 Query maxob=ss.createQuery("select max(esalary) from EmployeeHql");
		 List maxl=maxob.list();
		 System.out.println("Maximum sal="+maxl.get(0));
		
		 //average salary
		 Query avgob=ss.createQuery("select avg(esalary) from EmployeeHql");
		 List avgl=avgob.list();
		 System.out.println("Average sal="+avgl.get(0));
		
		//total number of employees
		 Query countob=ss.createQuery("select count(*) from EmployeeHql");
		 List countl=countob.list();
		 System.out.println("Employees Count="+countl.get(0));
		tran.commit();
		
		
		ss.close();
	}

}
